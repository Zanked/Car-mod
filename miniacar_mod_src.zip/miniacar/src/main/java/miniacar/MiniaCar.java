package miniacar;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod(modid = MiniaCar.MODID, name = "Minia Cars", version = "1.0.0", acceptedMinecraftVersions = "[1.12.2]")
public class MiniaCar {
    public static final String MODID = "miniacar";

    @Mod.Instance
    public static MiniaCar instance;

    public static final CreativeTabs TAB = new CreativeTabs("miniacar") {
        @Override
        public ItemStack createIcon() {
            return new ItemStack(ModItems.CAR, 1, 0);
        }
    };

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        CarConfig.load(event.getSuggestedConfigurationFile());
        NetworkHandler.init();
        NetworkRegistry.INSTANCE.registerGuiHandler(this, new GuiHandler());
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        if (event.getSide() == Side.CLIENT) {
            ClientEvents.registerKeys();
        }
    }
}
