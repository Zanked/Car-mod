package miniacar;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.IInventory;

public class ContainerTrunk extends ContainerChest {
    private final EntityCar car;

    public ContainerTrunk(IInventory playerInventory, EntityCar car, EntityPlayer player) {
        super(playerInventory, car.getTrunk(), player);
        this.car = car;
    }

    @Override
    public boolean canInteractWith(EntityPlayer player) {
        return !this.car.isDead && this.car.getDistanceSq(player) < 64.0D;
    }

    @Override
    public void onContainerClosed(EntityPlayer player) {
        super.onContainerClosed(player);
        if (!this.car.world.isRemote) {
            this.car.playTrunkSound(false);
        }
    }
}
