package miniacar;

import java.io.File;
import net.minecraftforge.common.config.Configuration;

public class CarConfig {
    /** Масштаб машины (1.0 = размер оригинальной модели, ~4.3 блока в длину). */
    public static float scale = 1.0F;
    /** Максимальная скорость вперёд, блоков в секунду. */
    public static float maxSpeed = 12.0F;
    /** Скрывать модель игроков/мобов, сидящих в машине (модель кабины очень маленькая). */
    public static boolean hideRiders = true;

    public static void load(File file) {
        Configuration c = new Configuration(file);
        scale = c.getFloat("scale", "general", 1.0F, 0.2F, 4.0F, "Car scale. 1.0 = original model size (about 4.3 blocks long).");
        maxSpeed = c.getFloat("maxSpeed", "general", 12.0F, 2.0F, 60.0F, "Max forward speed in blocks per second.");
        hideRiders = c.getBoolean("hideRiders", "client", true, "Do not render riders (the cabin is smaller than a player).");
        if (c.hasChanged()) c.save();
    }
}
