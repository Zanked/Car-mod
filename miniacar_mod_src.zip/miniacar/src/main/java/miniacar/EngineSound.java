package miniacar;

import net.minecraft.client.audio.MovingSound;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class EngineSound extends MovingSound {
    private final EntityCar car;
    private float smooth;
    private int age;

    public EngineSound(EntityCar car) {
        super(ModSounds.ENGINE, SoundCategory.NEUTRAL);
        this.car = car;
        this.repeat = true;
        this.repeatDelay = 0;
        this.volume = 0.01F;
        this.pitch = 0.7F;
        this.updatePos();
    }

    private void updatePos() {
        this.xPosF = (float) car.posX;
        this.yPosF = (float) car.posY;
        this.zPosF = (float) car.posZ;
    }

    @Override
    public void update() {
        if (car.isDead || car.getControllingPassenger() == null) {
            car.engineSoundActive = false;
            this.donePlaying = true;
            return;
        }
        this.updatePos();
        this.age++;
        float maxF = CarConfig.maxSpeed / 20.0F;
        float ratio = MathHelper.clamp((float) car.getSpeedH() / maxF, 0.0F, 1.2F);
        this.smooth += (ratio - this.smooth) * 0.15F;
        this.pitch = 0.7F + this.smooth * 1.1F;
        // первые ~1.4 с играет звук стартера, двигатель плавно включается после него
        float fade = MathHelper.clamp((this.age - 28) / 12.0F, 0.0F, 1.0F);
        this.volume = 0.01F + fade * (0.4F + 0.6F * Math.min(1.0F, this.smooth + 0.2F));
    }
}
