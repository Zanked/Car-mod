package miniacar;

import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class EntityCar extends Entity {
    private static final DataParameter<Integer> VARIANT = EntityDataManager.createKey(EntityCar.class, DataSerializers.VARINT);

    /** Сиденья: {смещение влево, смещение вперёд} в блоках при scale = 1. Начало координат - центр машины. */
    private static final double[][] SEATS = {
            {0.35D, 0.06D},    // 0: водитель (левый перед, рядом с рулём)
            {-0.35D, 0.06D},   // 1: пассажир спереди
            {0.33D, -1.06D},   // 2: сзади слева
            {-0.33D, -1.06D}   // 3: сзади справа
    };
    /** Кто на каком месте сидит: id сущности + 1, 0 = место свободно. */
    @SuppressWarnings("unchecked")
    private static final DataParameter<Integer>[] SEAT_IDS = new DataParameter[]{
            EntityDataManager.createKey(EntityCar.class, DataSerializers.VARINT),
            EntityDataManager.createKey(EntityCar.class, DataSerializers.VARINT),
            EntityDataManager.createKey(EntityCar.class, DataSerializers.VARINT),
            EntityDataManager.createKey(EntityCar.class, DataSerializers.VARINT)
    };
    private static final double SEAT_Y = 0.62D;

    /** Багажник: 27 слотов (3 ряда как у сундука). */
    private final InventoryBasic trunk = new InventoryBasic("container.miniacar.trunk", false, 27);

    private double speed;       // блоков/тик вдоль направления машины (только у того, кто ведёт)
    private float deltaYaw;
    private float damage;

    // --- анимация (используется рендером) ---
    public float wheelAngle, prevWheelAngle;
    public float steerAngle, prevSteerAngle;
    private double speedH;
    public boolean engineSoundActive;
    private int hornCooldown;
    private int crashCooldown;

    private int lerpSteps;
    private double lerpX, lerpY, lerpZ;
    private double lerpYaw;

    public EntityCar(World world) {
        super(world);
        float s = CarConfig.scale;
        this.setSize(2.3F * s, 2.2F * s);
        this.stepHeight = 1.0F * s;
        this.preventEntitySpawning = true;
    }

    @Override
    protected void entityInit() {
        this.dataManager.register(VARIANT, 0);
        for (DataParameter<Integer> p : SEAT_IDS) {
            this.dataManager.register(p, 0);
        }
    }

    public int getVariant() {
        return this.dataManager.get(VARIANT);
    }

    public void setVariant(int v) {
        this.dataManager.set(VARIANT, v);
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound c) {
        setVariant(c.getInteger("Variant"));
        NBTTagList list = c.getTagList("Trunk", 10);
        for (int i = 0; i < list.tagCount(); i++) {
            NBTTagCompound t = list.getCompoundTagAt(i);
            int slot = t.getByte("Slot") & 255;
            if (slot < this.trunk.getSizeInventory()) {
                this.trunk.setInventorySlotContents(slot, new ItemStack(t));
            }
        }
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound c) {
        c.setInteger("Variant", getVariant());
        NBTTagList list = new NBTTagList();
        for (int i = 0; i < this.trunk.getSizeInventory(); i++) {
            ItemStack st = this.trunk.getStackInSlot(i);
            if (!st.isEmpty()) {
                NBTTagCompound t = new NBTTagCompound();
                t.setByte("Slot", (byte) i);
                st.writeToNBT(t);
                list.appendTag(t);
            }
        }
        c.setTag("Trunk", list);
    }

    @Override
    public boolean canBeCollidedWith() {
        return !this.isDead;
    }

    @Override
    public ItemStack getPickedResult(RayTraceResult target) {
        return new ItemStack(ModItems.CAR, 1, getVariant());
    }

    // ---------------- взаимодействие ----------------

    /** Игрок кликнул по машине: садимся на место, ближайшее к точке клика. */
    @Override
    public EnumActionResult applyPlayerInteraction(EntityPlayer player, Vec3d vec, EnumHand hand) {
        if (this.isPassenger(player)) return EnumActionResult.PASS;
        if (player.isSneaking()) {
            // Shift + ПКМ: открыть багажник
            if (!this.world.isRemote) {
                this.playTrunkSound(true);
                player.openGui(MiniaCar.instance, GuiHandler.TRUNK, this.world, this.getEntityId(), 0, 0);
            }
            return EnumActionResult.SUCCESS;
        }
        if (!this.world.isRemote) {
            double r = Math.toRadians(this.rotationYaw);
            double fwd = -Math.sin(r) * vec.x + Math.cos(r) * vec.z;
            double lat = Math.cos(r) * vec.x + Math.sin(r) * vec.z;
            this.tryMount(player, this.nearestFreeSeat(lat, fwd));
        }
        return EnumActionResult.SUCCESS;
    }

    @Override
    public boolean processInitialInteract(EntityPlayer player, EnumHand hand) {
        if (!this.world.isRemote && !player.isSneaking() && !this.isPassenger(player)) {
            this.tryMount(player, this.nearestFreeSeat(0.0D, 0.0D));
        }
        return true;
    }

    private boolean tryMount(EntityPlayer player, int seat) {
        if (seat < 0) return false;
        this.dataManager.set(SEAT_IDS[seat], player.getEntityId() + 1);
        if (player.startRiding(this)) {
            this.world.playSound(null, this.posX, this.posY, this.posZ, ModSounds.DOOR, SoundCategory.NEUTRAL, 0.9F, 1.0F);
            if (seat == 0) {
                this.world.playSound(null, this.posX, this.posY, this.posZ, ModSounds.START, SoundCategory.NEUTRAL, 0.9F, 1.0F);
            }
            return true;
        }
        this.dataManager.set(SEAT_IDS[seat], 0);
        return false;
    }

    // ---------------- места ----------------

    private int getSeatOf(Entity e) {
        int id = e.getEntityId() + 1;
        for (int i = 0; i < SEATS.length; i++) {
            if (this.dataManager.get(SEAT_IDS[i]) == id) return i;
        }
        return -1;
    }

    @Nullable
    private Entity getSeatOccupant(int seat) {
        int id = this.dataManager.get(SEAT_IDS[seat]);
        if (id <= 0) return null;
        Entity e = this.world.getEntityByID(id - 1);
        return (e != null && this.isPassenger(e)) ? e : null;
    }

    /** Ближайшее к точке (влево, вперёд) свободное место или -1. */
    private int nearestFreeSeat(double lat, double fwd) {
        float s = CarConfig.scale;
        int best = -1;
        double bd = Double.MAX_VALUE;
        for (int i = 0; i < SEATS.length; i++) {
            if (this.getSeatOccupant(i) != null) continue;
            double dl = lat - SEATS[i][0] * s;
            double df = fwd - SEATS[i][1] * s;
            double d = dl * dl + df * df;
            if (d < bd) {
                bd = d;
                best = i;
            }
        }
        return best;
    }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) {
        if (this.isEntityInvulnerable(source)) return false;
        if (this.world.isRemote || this.isDead) return true;
        Entity attacker = source.getTrueSource();
        if (attacker != null && this.isPassenger(attacker)) return false;
        boolean creative = attacker instanceof EntityPlayer && ((EntityPlayer) attacker).capabilities.isCreativeMode;
        this.damage += creative ? 100.0F : amount * 10.0F;
        if (this.damage >= 40.0F) {
            InventoryHelper.dropInventoryItems(this.world, this.posX, this.posY, this.posZ, this.trunk);
            if (!creative && this.world.getGameRules().getBoolean("doEntityDrops")) {
                this.entityDropItem(new ItemStack(ModItems.CAR, 1, getVariant()), 0.0F);
            }
            this.setDead();
        }
        return true;
    }

    // ---------------- пассажиры ----------------

    @Override
    protected boolean canFitPassenger(Entity passenger) {
        return this.getPassengers().size() < SEATS.length;
    }

    /** Ведёт только тот, кто сидит на месте водителя. */
    @Nullable
    @Override
    public Entity getControllingPassenger() {
        return this.getSeatOccupant(0);
    }

    @Override
    public double getMountedYOffset() {
        return SEAT_Y * CarConfig.scale;
    }

    @Override
    public void updatePassenger(Entity passenger) {
        if (!this.isPassenger(passenger)) return;
        int i = this.getSeatOf(passenger);
        if (i < 0) {
            if (!this.world.isRemote) {
                // пассажир без места (например, после перезагрузки мира): даём первое свободное
                for (int k = 0; k < SEATS.length; k++) {
                    if (this.getSeatOccupant(k) == null) {
                        this.dataManager.set(SEAT_IDS[k], passenger.getEntityId() + 1);
                        i = k;
                        break;
                    }
                }
            }
            if (i < 0) i = Math.max(0, Math.min(this.getPassengers().indexOf(passenger), SEATS.length - 1));
        }
        float s = CarConfig.scale;
        double lat = SEATS[i][0] * s;
        double fwd = SEATS[i][1] * s;
        double r = Math.toRadians(this.rotationYaw);
        double x = this.posX - Math.sin(r) * fwd + Math.cos(r) * lat;
        double z = this.posZ + Math.cos(r) * fwd + Math.sin(r) * lat;
        passenger.setPosition(x, this.posY + SEAT_Y * s + passenger.getYOffset(), z);
        passenger.rotationYaw += this.deltaYaw;
        passenger.setRotationYawHead(passenger.getRotationYawHead() + this.deltaYaw);
        this.applyYaw(passenger);
    }

    @Override
    protected void removePassenger(Entity passenger) {
        super.removePassenger(passenger);
        if (!this.world.isRemote) {
            int seat = this.getSeatOf(passenger);
            if (seat >= 0) this.dataManager.set(SEAT_IDS[seat], 0);
            this.world.playSound(null, this.posX, this.posY, this.posZ, ModSounds.DOOR, SoundCategory.NEUTRAL, 0.8F, 0.95F);
        }
    }

    public InventoryBasic getTrunk() {
        return this.trunk;
    }

    public void playTrunkSound(boolean open) {
        this.world.playSound(null, this.posX, this.posY, this.posZ,
                open ? ModSounds.TRUNK_OPEN : ModSounds.TRUNK_CLOSE, SoundCategory.NEUTRAL, 0.9F, 1.0F);
    }

    public void honk() {
        if (this.hornCooldown > 0) return;
        this.hornCooldown = 10;
        this.world.playSound(null, this.posX, this.posY, this.posZ, ModSounds.HORN, SoundCategory.NEUTRAL, 1.6F, 1.0F);
    }

    public double getSpeedH() {
        return this.speedH;
    }

    private void applyYaw(Entity e) {
        e.setRenderYawOffset(this.rotationYaw);
        float f = MathHelper.wrapDegrees(e.rotationYaw - this.rotationYaw);
        float f1 = MathHelper.clamp(f, -120.0F, 120.0F);
        e.prevRotationYaw += f1 - f;
        e.rotationYaw += f1 - f;
        e.setRotationYawHead(e.rotationYaw);
    }

    @SideOnly(Side.CLIENT)
    @Override
    public void applyOrientationToEntity(Entity e) {
        this.applyYaw(e);
    }

    // ---------------- синхронизация позиции у наблюдателей ----------------

    @SideOnly(Side.CLIENT)
    @Override
    public void setPositionAndRotationDirect(double x, double y, double z, float yaw, float pitch, int posRotationIncrements, boolean teleport) {
        this.lerpX = x;
        this.lerpY = y;
        this.lerpZ = z;
        this.lerpYaw = yaw;
        this.lerpSteps = 10;
    }

    private void tickLerp() {
        if (this.lerpSteps > 0 && !this.canPassengerSteer()) {
            double nx = this.posX + (this.lerpX - this.posX) / this.lerpSteps;
            double ny = this.posY + (this.lerpY - this.posY) / this.lerpSteps;
            double nz = this.posZ + (this.lerpZ - this.posZ) / this.lerpSteps;
            double dyaw = MathHelper.wrapDegrees(this.lerpYaw - this.rotationYaw);
            this.rotationYaw = (float) (this.rotationYaw + dyaw / this.lerpSteps);
            this.lerpSteps--;
            this.setPosition(nx, ny, nz);
            this.setRotation(this.rotationYaw, this.rotationPitch);
        }
    }

    // ---------------- физика / управление ----------------

    @Override
    public void onUpdate() {
        super.onUpdate();
        this.tickLerp();
        this.deltaYaw = 0.0F;
        if (this.canPassengerSteer()) {
            this.drive();
        }
        if (this.hornCooldown > 0) this.hornCooldown--;
        if (this.crashCooldown > 0) this.crashCooldown--;
        this.animate();
        if (this.world.isRemote && !this.engineSoundActive && this.getControllingPassenger() != null) {
            this.engineSoundActive = true;
            ClientSoundHooks.startEngine(this);
        }
    }

    /** Вращение колёс по пройденному пути и поворот передних колёс по повороту кузова. */
    private void animate() {
        double dx = this.posX - this.prevPosX;
        double dz = this.posZ - this.prevPosZ;
        double r = Math.toRadians(this.rotationYaw);
        double fwd = dx * (-Math.sin(r)) + dz * Math.cos(r);
        this.speedH = Math.sqrt(dx * dx + dz * dz);

        this.prevWheelAngle = this.wheelAngle;
        this.wheelAngle += (float) (fwd / (0.375D * CarConfig.scale) * 57.29578D);
        if (this.wheelAngle > 360.0F) {
            this.wheelAngle -= 360.0F;
            this.prevWheelAngle -= 360.0F;
        } else if (this.wheelAngle < -360.0F) {
            this.wheelAngle += 360.0F;
            this.prevWheelAngle += 360.0F;
        }

        this.prevSteerAngle = this.steerAngle;
        float yawChange = MathHelper.wrapDegrees(this.rotationYaw - this.prevRotationYaw);
        float target = 0.0F;
        if (Math.abs(fwd) > 0.02D) {
            target = MathHelper.clamp(-yawChange / 3.5F * 25.0F * (float) Math.signum(fwd), -28.0F, 28.0F);
        }
        this.steerAngle += (target - this.steerAngle) * 0.4F;
    }

    private void drive() {
        float forward = 0.0F;
        float strafe = 0.0F;
        Entity c = this.getControllingPassenger();
        if (c instanceof EntityLivingBase) {
            EntityLivingBase l = (EntityLivingBase) c;
            forward = l.moveForward;
            strafe = l.moveStrafing;
        }

        double maxF = CarConfig.maxSpeed / 20.0D;
        double maxR = maxF * 0.35D;
        double acc = maxF / 25.0D;

        if (forward > 0.0F) {
            this.speed += acc;
        } else if (forward < 0.0F) {
            this.speed -= (this.speed > 0.0D) ? acc * 2.5D : acc * 0.8D;
        } else {
            this.speed *= this.onGround ? 0.95D : 0.99D;
            if (Math.abs(this.speed) < 0.005D) this.speed = 0.0D;
        }
        this.speed = MathHelper.clamp(this.speed, -maxR, maxF);

        if (Math.abs(this.speed) > 0.01D) {
            double k = Math.min(1.0D, Math.abs(this.speed) / 0.2D);
            float dy = (float) (-strafe * 3.5D * Math.signum(this.speed) * k);
            this.rotationYaw += dy;
            this.deltaYaw = dy;
        }

        double r = Math.toRadians(this.rotationYaw);
        this.motionX = -Math.sin(r) * this.speed;
        this.motionZ = Math.cos(r) * this.speed;

        if (this.isInWater()) {
            this.motionY = Math.min(this.motionY + 0.04D, 0.1D);
            this.speed *= 0.9D;
        } else {
            this.motionY -= 0.08D;
            this.motionY *= 0.98D;
        }

        this.move(MoverType.SELF, this.motionX, this.motionY, this.motionZ);

        if (this.onGround && this.motionY < 0.0D) this.motionY = 0.0D;
        if (this.collidedHorizontally) {
            if (Math.abs(this.speed) > maxF * 0.35D && this.crashCooldown <= 0 && this.world.isRemote) {
                this.world.playSound(this.posX, this.posY, this.posZ, ModSounds.CRASH, SoundCategory.NEUTRAL,
                        1.0F, 0.9F + this.rand.nextFloat() * 0.2F, false);
                this.crashCooldown = 15;
            }
            this.speed *= 0.6D;
        }
    }
}
