package miniacar;

import net.minecraft.item.Item;

public class ModItems {
    public static Item CAR;
}
