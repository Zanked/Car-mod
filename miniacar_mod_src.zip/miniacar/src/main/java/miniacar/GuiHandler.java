package miniacar;

import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;

public class GuiHandler implements IGuiHandler {
    public static final int TRUNK = 0;

    @Override
    public Object getServerGuiElement(int id, EntityPlayer player, World world, int x, int y, int z) {
        if (id == TRUNK) {
            Entity e = world.getEntityByID(x);
            if (e instanceof EntityCar) return new ContainerTrunk(player.inventory, (EntityCar) e, player);
        }
        return null;
    }

    @Override
    public Object getClientGuiElement(int id, EntityPlayer player, World world, int x, int y, int z) {
        if (id == TRUNK) {
            Entity e = world.getEntityByID(x);
            if (e instanceof EntityCar) return new GuiChest(player.inventory, ((EntityCar) e).getTrunk());
        }
        return null;
    }
}
