package miniacar;

import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.model.pipeline.LightUtil;
import org.lwjgl.opengl.GL11;

public class RenderCar extends Render<EntityCar> {

    public RenderCar(RenderManager manager) {
        super(manager);
        this.shadowSize = 0.9F * CarConfig.scale;
    }

    @Override
    public void doRender(EntityCar car, double x, double y, double z, float yaw, float partialTicks) {
        int v = car.getVariant() & 3;
        IBakedModel front = ClientModels.FRONT[v];
        IBakedModel back = ClientModels.BACK[v];
        if (front == null || back == null) return;

        GlStateManager.pushMatrix();
        GlStateManager.translate((float) x, (float) y, (float) z);
        GlStateManager.rotate(-yaw, 0.0F, 1.0F, 0.0F);
        float s = CarConfig.scale;
        GlStateManager.scale(s, s, s);
        // начало координат сущности: центр по X, земля по Y, середина колёсной базы по Z
        GlStateManager.translate(-0.5F, 1.0F, 0.6875F);

        this.bindTexture(TextureMap.LOCATION_BLOCKS_TEXTURE);
        GlStateManager.enableRescaleNormal();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA,
                GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);

        float spin = car.prevWheelAngle + (car.wheelAngle - car.prevWheelAngle) * partialTicks;
        float steer = car.prevSteerAngle + (car.steerAngle - car.prevSteerAngle) * partialTicks;

        draw(front);
        drawWheel(0, spin, steer);
        drawWheel(1, spin, steer);
        GlStateManager.translate(0.0F, 0.0F, -3.0F); // задняя половина сдвинута на 3 блока назад
        draw(back);
        drawWheel(2, spin, 0.0F);
        drawWheel(3, spin, 0.0F);

        GlStateManager.disableBlend();
        GlStateManager.disableRescaleNormal();
        GlStateManager.popMatrix();
        super.doRender(car, x, y, z, yaw, partialTicks);
    }

    /** Центры колёс в координатах оригинальной модели (1/16 блока): x, y, z. */
    private static final float[][] WHEEL = {
            {-7.11F, -10.0F, 11.13F}, {23.11F, -10.0F, 11.13F},
            {-7.11F, -10.0F, 12.33F}, {23.11F, -10.0F, 12.33F}
    };

    private static void drawWheel(int i, float spin, float steer) {
        IBakedModel wheel = ClientModels.WHEELS[i];
        if (wheel == null) return;
        float cx = WHEEL[i][0] / 16.0F;
        float cy = WHEEL[i][1] / 16.0F;
        float cz = WHEEL[i][2] / 16.0F;
        GlStateManager.pushMatrix();
        GlStateManager.translate(cx, cy, cz);
        if (i < 2) GlStateManager.rotate(steer, 0.0F, 1.0F, 0.0F);
        GlStateManager.rotate(spin, 1.0F, 0.0F, 0.0F);
        GlStateManager.translate(-cx, -cy, -cz);
        draw(wheel);
        GlStateManager.popMatrix();
    }

    private static void draw(IBakedModel model) {
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuffer();
        buf.begin(GL11.GL_QUADS, DefaultVertexFormats.ITEM);
        for (BakedQuad q : model.getQuads(null, null, 0L)) {
            LightUtil.renderQuadColor(buf, q, 0xFFFFFFFF);
        }
        for (EnumFacing f : EnumFacing.values()) {
            for (BakedQuad q : model.getQuads(null, f, 0L)) {
                LightUtil.renderQuadColor(buf, q, 0xFFFFFFFF);
            }
        }
        tess.draw();
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityCar entity) {
        return TextureMap.LOCATION_BLOCKS_TEXTURE;
    }
}
