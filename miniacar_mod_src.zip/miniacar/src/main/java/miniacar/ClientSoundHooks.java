package miniacar;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class ClientSoundHooks {
    public static void startEngine(EntityCar car) {
        Minecraft.getMinecraft().getSoundHandler().playSound(new EngineSound(car));
    }
}
