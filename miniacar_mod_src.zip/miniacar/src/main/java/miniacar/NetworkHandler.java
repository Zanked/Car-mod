package miniacar;

import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public class NetworkHandler {
    public static SimpleNetworkWrapper CHANNEL;

    public static void init() {
        CHANNEL = NetworkRegistry.INSTANCE.newSimpleChannel(MiniaCar.MODID);
        CHANNEL.registerMessage(HonkMessage.Handler.class, HonkMessage.class, 0, Side.SERVER);
    }
}
