package miniacar;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import org.lwjgl.input.Keyboard;

@Mod.EventBusSubscriber(value = Side.CLIENT, modid = MiniaCar.MODID)
public class ClientEvents {
    public static final KeyBinding HORN = new KeyBinding("key.miniacar.horn", Keyboard.KEY_H, "key.categories.miniacar");

    public static void registerKeys() {
        ClientRegistry.registerKeyBinding(HORN);
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null) return;
        while (HORN.isPressed()) {
            if (mc.player.getRidingEntity() instanceof EntityCar) {
                NetworkHandler.CHANNEL.sendToServer(new HonkMessage());
            }
        }
    }
}
