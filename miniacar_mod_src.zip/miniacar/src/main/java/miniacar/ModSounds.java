package miniacar;

import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.registries.IForgeRegistry;

public class ModSounds {
    public static SoundEvent ENGINE, START, DOOR, CRASH, HORN, TRUNK_OPEN, TRUNK_CLOSE;

    private static SoundEvent make(String name) {
        ResourceLocation rl = new ResourceLocation(MiniaCar.MODID, name);
        return new SoundEvent(rl).setRegistryName(rl);
    }

    public static void register(IForgeRegistry<SoundEvent> registry) {
        ENGINE = make("engine_loop");
        START = make("engine_start");
        DOOR = make("door");
        CRASH = make("crash");
        HORN = make("horn");
        TRUNK_OPEN = make("trunk_open");
        TRUNK_CLOSE = make("trunk_close");
        registry.registerAll(ENGINE, START, DOOR, CRASH, HORN, TRUNK_OPEN, TRUNK_CLOSE);
    }
}
