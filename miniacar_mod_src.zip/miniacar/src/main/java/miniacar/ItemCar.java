package miniacar;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class ItemCar extends Item {
    public static final int VARIANTS = 4;

    public ItemCar() {
        setRegistryName(MiniaCar.MODID, "car");
        setTranslationKey(MiniaCar.MODID + ".car");
        setCreativeTab(MiniaCar.TAB);
        setHasSubtypes(true);
        setMaxDamage(0);
        setMaxStackSize(16);
    }

    @Override
    public String getTranslationKey(ItemStack stack) {
        return super.getTranslationKey() + "." + (stack.getMetadata() % VARIANTS);
    }

    @Override
    public void getSubItems(CreativeTabs tab, NonNullList<ItemStack> items) {
        if (isInCreativeTab(tab)) {
            for (int i = 0; i < VARIANTS; i++) items.add(new ItemStack(this, 1, i));
        }
    }

    @Override
    public EnumActionResult onItemUse(EntityPlayer player, World world, BlockPos pos, EnumHand hand,
                                      EnumFacing facing, float hitX, float hitY, float hitZ) {
        ItemStack stack = player.getHeldItem(hand);
        BlockPos target = pos.offset(facing);
        if (!world.isRemote) {
            EntityCar car = new EntityCar(world);
            car.setVariant(stack.getMetadata() % VARIANTS);
            car.setLocationAndAngles(target.getX() + 0.5D, target.getY(), target.getZ() + 0.5D, player.rotationYaw, 0.0F);
            if (!world.getCollisionBoxes(car, car.getEntityBoundingBox()).isEmpty()) {
                return EnumActionResult.FAIL;
            }
            world.spawnEntity(car);
            if (!player.capabilities.isCreativeMode) stack.shrink(1);
        }
        return EnumActionResult.SUCCESS;
    }
}
