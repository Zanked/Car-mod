package miniacar;

import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.EntityEntry;
import net.minecraftforge.fml.common.registry.EntityEntryBuilder;

@Mod.EventBusSubscriber(modid = MiniaCar.MODID)
public class CommonRegistry {

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        ModItems.CAR = new ItemCar();
        event.getRegistry().register(ModItems.CAR);
    }

    @SubscribeEvent
    public static void registerEntities(RegistryEvent.Register<EntityEntry> event) {
        EntityEntry entry = EntityEntryBuilder.<Entity>create()
                .entity(EntityCar.class)
                .id(new ResourceLocation(MiniaCar.MODID, "car"), 0)
                .name(MiniaCar.MODID + ".car")
                .tracker(96, 3, true)
                .build();
        event.getRegistry().register(entry);
    }
}
