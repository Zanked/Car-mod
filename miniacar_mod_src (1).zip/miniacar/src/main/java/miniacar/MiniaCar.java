package miniacar;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = MiniaCar.MODID, name = "Minia Cars", version = "1.0.0", acceptedMinecraftVersions = "[1.12.2]")
public class MiniaCar {
    public static final String MODID = "miniacar";

    public static final CreativeTabs TAB = new CreativeTabs("miniacar") {
        @Override
        public ItemStack createIcon() {
            return new ItemStack(ModItems.CAR, 1, 0);
        }
    };

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        CarConfig.load(event.getSuggestedConfigurationFile());
    }
}
