package miniacar;

import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.ModelBakeEvent;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.TextureStitchEvent;
import net.minecraftforge.client.model.IModel;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.model.ModelLoaderRegistry;
import net.minecraftforge.common.model.TRSRTransformation;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(value = Side.CLIENT, modid = MiniaCar.MODID)
public class ClientModels {
    public static final IBakedModel[] FRONT = new IBakedModel[ItemCar.VARIANTS];
    public static final IBakedModel[] BACK = new IBakedModel[ItemCar.VARIANTS];

    @SubscribeEvent
    public static void onModelRegistry(ModelRegistryEvent event) {
        RenderingRegistry.registerEntityRenderingHandler(EntityCar.class, manager -> new RenderCar(manager));
        for (int v = 0; v < ItemCar.VARIANTS; v++) {
            ModelLoader.setCustomModelResourceLocation(ModItems.CAR, v,
                    new ModelResourceLocation(MiniaCar.MODID + ":car_" + v, "inventory"));
        }
    }

    @SubscribeEvent
    public static void onStitch(TextureStitchEvent.Pre event) {
        TextureMap map = event.getMap();
        for (int v = 1; v <= ItemCar.VARIANTS; v++) {
            map.registerSprite(new ResourceLocation(MiniaCar.MODID, "blocks/car_" + v));
        }
    }

    @SubscribeEvent
    public static void onBake(ModelBakeEvent event) {
        for (int v = 0; v < ItemCar.VARIANTS; v++) {
            FRONT[v] = bake("block/car_front_" + (v + 1));
            BACK[v] = bake("block/car_back_" + (v + 1));
        }
    }

    private static IBakedModel bake(String path) {
        try {
            IModel model = ModelLoaderRegistry.getModel(new ResourceLocation(MiniaCar.MODID, path));
            return model.bake(TRSRTransformation.identity(), DefaultVertexFormats.ITEM, ModelLoader.defaultTextureGetter());
        } catch (Exception e) {
            System.err.println("[miniacar] Failed to bake model " + path);
            e.printStackTrace();
            return null;
        }
    }

    @SubscribeEvent
    public static void onRenderLiving(RenderLivingEvent.Pre event) {
        EntityLivingBase e = event.getEntity();
        if (CarConfig.hideRiders && e.getRidingEntity() instanceof EntityCar) {
            event.setCanceled(true);
        }
    }
}
