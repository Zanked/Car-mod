package miniacar;

import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class EntityCar extends Entity {
    private static final DataParameter<Integer> VARIANT = EntityDataManager.createKey(EntityCar.class, DataSerializers.VARINT);

    /** Сиденья: {смещение влево, смещение вперёд} в блоках при scale = 1. Начало координат - центр машины. */
    private static final double[][] SEATS = {
            {0.31D, -0.25D},   // водитель (левый перед)
            {-0.31D, -0.25D},  // пассажир спереди
            {0.31D, -1.19D},   // сзади слева
            {-0.31D, -1.19D}   // сзади справа
    };
    private static final double SEAT_Y = 0.62D;

    private double speed;       // блоков/тик вдоль направления машины (только у того, кто ведёт)
    private float deltaYaw;
    private float damage;

    private int lerpSteps;
    private double lerpX, lerpY, lerpZ;
    private double lerpYaw;

    public EntityCar(World world) {
        super(world);
        float s = CarConfig.scale;
        this.setSize(2.3F * s, 2.2F * s);
        this.stepHeight = 1.0F * s;
        this.preventEntitySpawning = true;
    }

    @Override
    protected void entityInit() {
        this.dataManager.register(VARIANT, 0);
    }

    public int getVariant() {
        return this.dataManager.get(VARIANT);
    }

    public void setVariant(int v) {
        this.dataManager.set(VARIANT, v);
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound c) {
        setVariant(c.getInteger("Variant"));
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound c) {
        c.setInteger("Variant", getVariant());
    }

    @Override
    public boolean canBeCollidedWith() {
        return !this.isDead;
    }

    @Override
    public ItemStack getPickedResult(RayTraceResult target) {
        return new ItemStack(ModItems.CAR, 1, getVariant());
    }

    // ---------------- взаимодействие ----------------

    @Override
    public boolean processInitialInteract(EntityPlayer player, EnumHand hand) {
        if (!this.world.isRemote && !player.isSneaking()) {
            player.startRiding(this);
        }
        return true;
    }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) {
        if (this.isEntityInvulnerable(source)) return false;
        if (this.world.isRemote || this.isDead) return true;
        Entity attacker = source.getTrueSource();
        if (attacker != null && this.isPassenger(attacker)) return false;
        boolean creative = attacker instanceof EntityPlayer && ((EntityPlayer) attacker).capabilities.isCreativeMode;
        this.damage += creative ? 100.0F : amount * 10.0F;
        if (this.damage >= 40.0F) {
            if (!creative && this.world.getGameRules().getBoolean("doEntityDrops")) {
                this.entityDropItem(new ItemStack(ModItems.CAR, 1, getVariant()), 0.0F);
            }
            this.setDead();
        }
        return true;
    }

    // ---------------- пассажиры ----------------

    @Override
    protected boolean canFitPassenger(Entity passenger) {
        return this.getPassengers().size() < SEATS.length;
    }

    @Nullable
    @Override
    public Entity getControllingPassenger() {
        return this.getPassengers().isEmpty() ? null : this.getPassengers().get(0);
    }

    @Override
    public double getMountedYOffset() {
        return SEAT_Y * CarConfig.scale;
    }

    @Override
    public void updatePassenger(Entity passenger) {
        if (!this.isPassenger(passenger)) return;
        int i = this.getPassengers().indexOf(passenger);
        if (i < 0 || i >= SEATS.length) i = 0;
        float s = CarConfig.scale;
        double lat = SEATS[i][0] * s;
        double fwd = SEATS[i][1] * s;
        double r = Math.toRadians(this.rotationYaw);
        double x = this.posX - Math.sin(r) * fwd + Math.cos(r) * lat;
        double z = this.posZ + Math.cos(r) * fwd + Math.sin(r) * lat;
        passenger.setPosition(x, this.posY + SEAT_Y * s + passenger.getYOffset(), z);
        passenger.rotationYaw += this.deltaYaw;
        passenger.setRotationYawHead(passenger.getRotationYawHead() + this.deltaYaw);
        this.applyYaw(passenger);
    }

    private void applyYaw(Entity e) {
        e.setRenderYawOffset(this.rotationYaw);
        float f = MathHelper.wrapDegrees(e.rotationYaw - this.rotationYaw);
        float f1 = MathHelper.clamp(f, -120.0F, 120.0F);
        e.prevRotationYaw += f1 - f;
        e.rotationYaw += f1 - f;
        e.setRotationYawHead(e.rotationYaw);
    }

    @SideOnly(Side.CLIENT)
    @Override
    public void applyOrientationToEntity(Entity e) {
        this.applyYaw(e);
    }

    // ---------------- синхронизация позиции у наблюдателей ----------------

    @SideOnly(Side.CLIENT)
    @Override
    public void setPositionAndRotationDirect(double x, double y, double z, float yaw, float pitch, int posRotationIncrements, boolean teleport) {
        this.lerpX = x;
        this.lerpY = y;
        this.lerpZ = z;
        this.lerpYaw = yaw;
        this.lerpSteps = 10;
    }

    private void tickLerp() {
        if (this.lerpSteps > 0 && !this.canPassengerSteer()) {
            double nx = this.posX + (this.lerpX - this.posX) / this.lerpSteps;
            double ny = this.posY + (this.lerpY - this.posY) / this.lerpSteps;
            double nz = this.posZ + (this.lerpZ - this.posZ) / this.lerpSteps;
            double dyaw = MathHelper.wrapDegrees(this.lerpYaw - this.rotationYaw);
            this.rotationYaw = (float) (this.rotationYaw + dyaw / this.lerpSteps);
            this.lerpSteps--;
            this.setPosition(nx, ny, nz);
            this.setRotation(this.rotationYaw, this.rotationPitch);
        }
    }

    // ---------------- физика / управление ----------------

    @Override
    public void onUpdate() {
        super.onUpdate();
        this.tickLerp();
        this.deltaYaw = 0.0F;
        if (this.canPassengerSteer()) {
            this.drive();
        }
    }

    private void drive() {
        float forward = 0.0F;
        float strafe = 0.0F;
        Entity c = this.getControllingPassenger();
        if (c instanceof EntityLivingBase) {
            EntityLivingBase l = (EntityLivingBase) c;
            forward = l.moveForward;
            strafe = l.moveStrafing;
        }

        double maxF = CarConfig.maxSpeed / 20.0D;
        double maxR = maxF * 0.35D;
        double acc = maxF / 25.0D;

        if (forward > 0.0F) {
            this.speed += acc;
        } else if (forward < 0.0F) {
            this.speed -= (this.speed > 0.0D) ? acc * 2.5D : acc * 0.8D;
        } else {
            this.speed *= this.onGround ? 0.95D : 0.99D;
            if (Math.abs(this.speed) < 0.005D) this.speed = 0.0D;
        }
        this.speed = MathHelper.clamp(this.speed, -maxR, maxF);

        if (Math.abs(this.speed) > 0.01D) {
            double k = Math.min(1.0D, Math.abs(this.speed) / 0.2D);
            float dy = (float) (-strafe * 3.5D * Math.signum(this.speed) * k);
            this.rotationYaw += dy;
            this.deltaYaw = dy;
        }

        double r = Math.toRadians(this.rotationYaw);
        this.motionX = -Math.sin(r) * this.speed;
        this.motionZ = Math.cos(r) * this.speed;

        if (this.isInWater()) {
            this.motionY = Math.min(this.motionY + 0.04D, 0.1D);
            this.speed *= 0.9D;
        } else {
            this.motionY -= 0.08D;
            this.motionY *= 0.98D;
        }

        this.move(MoverType.SELF, this.motionX, this.motionY, this.motionZ);

        if (this.onGround && this.motionY < 0.0D) this.motionY = 0.0D;
        if (this.collidedHorizontally) this.speed *= 0.6D;
    }
}
